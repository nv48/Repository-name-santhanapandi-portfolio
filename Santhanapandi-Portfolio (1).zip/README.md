# Santhanapandi G — Portfolio

A responsive single-page portfolio inspired by the structure of the reference portfolio, customized for:
- ECE
- EV Technology
- EV Battery Systems / BMS
- Embedded Systems
- Electronics
- Robotics projects

## GitHub Pages
1. Create a GitHub repository named `santhanapandi-portfolio`.
2. Upload `index.html`.
3. Open Settings → Pages.
4. Select the `main` branch and `/ (root)`.
5. GitHub will provide your live Pages URL.

The final URL will normally look like:
`https://YOUR-GITHUB-USERNAME.github.io/santhanapandi-portfolio/`

Your GitHub username was not provided, so I have not invented it.
